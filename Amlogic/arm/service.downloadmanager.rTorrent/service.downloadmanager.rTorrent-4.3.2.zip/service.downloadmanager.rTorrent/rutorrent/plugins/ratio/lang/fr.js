﻿/*
 * PLUGIN RATIO
 *
 * French language file.
 *
 * Author: Nicobubulle (nicobubulle@gmail.com)
 */

 theUILang.ratios		= "Ratios";
 theUILang.ratio		= "Ratio";
 theUILang.mnuRatio		= "Affecter un ratio";
 theUILang.mnuRatioUnlimited	= "Pas de ratio";
 theUILang.ratioName		= "Nom";
 theUILang.minRatio		= "Min";
 theUILang.maxRatio		= "Max";
 theUILang.ratioUpload		= "Envoi";
 theUILang.ratioAction		= "Action";
 theUILang.ratioStop		= "Arrêt";
 theUILang.ratioStopAndRemove	= "Arrêt/retrait du gpe";
 theUILang.ratioErase		= "Efface";
 theUILang.ratioEraseData	= "Supprime les données";
 theUILang.maxTime		= "Temps";
 theUILang.ratioDefault 	= "Groupe de ratio par défaut";
 theUILang.setThrottleTo	= "Appliquer la vitesse";

thePlugins.get("ratio").langLoaded();