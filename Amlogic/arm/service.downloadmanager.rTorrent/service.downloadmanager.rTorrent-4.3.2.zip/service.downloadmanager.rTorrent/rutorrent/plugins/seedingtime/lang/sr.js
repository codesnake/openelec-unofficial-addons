﻿/*
 * PLUGIN SeedingTime
 *
 * Serbian language file.
 *
 * Author: Zoltan Csala (zcsala021 at gmail dot com))
 */

 theUILang.seedingTime		= "Завршено";
 theUILang.addTime		= "Added";

thePlugins.get("seedingtime").langLoaded();