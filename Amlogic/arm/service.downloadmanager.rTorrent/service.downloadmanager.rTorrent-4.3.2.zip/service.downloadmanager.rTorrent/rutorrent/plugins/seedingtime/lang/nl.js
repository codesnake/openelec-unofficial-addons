﻿/*
 * PLUGIN SeedingTime
 *
 * Dutch language file.
 *
 * Author: rascalli (rascallim@gmail.com)
 */

 theUILang.seedingTime		= "Finished";
 theUILang.addTime		= "Toegevoegd";

thePlugins.get("seedingtime").langLoaded();