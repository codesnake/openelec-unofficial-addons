<?php

	// interval for schedule command of garbage checker in seconds
	$garbageCheckInterval = 15;

	$erasedebug_enabled = false;
