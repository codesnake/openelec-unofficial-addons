﻿/*
 * PLUGIN DATADIR
 *
 * Polish language file.
 *
 * Author: Dare (piczok@gmail.com)
 */

 theUILang.DataDir		= "Zapisz do";
 theUILang.DataDirMove		= "Przenieś pliki danych";
 theUILang.datadirDlgCaption	= "Katalog danych Torrent";
 theUILang.datadirDirNotFound	= "Wtyczka DataDir: Niepoprawny katalog";
 theUILang.datadirSetDirFail	= "Wtyczka DataDir: Operacja się nie udała";
 theUILang.datadirPHPNotFound	= "Wtyczka DataDir: User rTorrenta nie ma dostępu do interpretera PHP. Plugin nie zadziała.";

thePlugins.get("datadir").langLoaded();