﻿/*
 * PLUGIN DATADIR
 *
 * Serbian language file.
 *
 * Author: Zoltan Csala (zcsala021 at gmail dot com)
 */

 theUILang.DataDir		= "Сними у";
 theUILang.DataDirMove		= "Move data files";
 theUILang.datadirDlgCaption	= "Директоријум података за торент";
 theUILang.datadirDirNotFound	= "Додатак DataDir: Погрешан директоријум";
 theUILang.datadirSetDirFail	= "Додатак DataDir: rXMLRPCRequest() није успео";
 theUILang.datadirPHPNotFound	= "DataDir plugin: rTorrent user can't access php interpreter. Plugin will not work.";

thePlugins.get("datadir").langLoaded();