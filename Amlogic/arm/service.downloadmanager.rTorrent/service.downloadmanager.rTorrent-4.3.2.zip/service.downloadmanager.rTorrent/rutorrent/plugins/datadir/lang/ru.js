﻿/*
 * PLUGIN DATADIR
 *
 * Russian language file.
 *
 * Author: 
 */

 theUILang.DataDir		= "Сохранить в";
 theUILang.DataDirMove		= "Перенести файлы данных";
 theUILang.datadirDlgCaption	= "Настройка каталога данных";
 theUILang.datadirDirNotFound	= "Плагин DataDir: Недопустимый каталог";
 theUILang.datadirSetDirFail	= "Плагин DataDir: Операция не выполнена";
 theUILang.datadirPHPNotFound	= "Плагин DataDir: пользователю rTorrent не доступен интерпретатор php. Плагин не будет работать.";

thePlugins.get("datadir").langLoaded();